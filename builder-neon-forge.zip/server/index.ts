import "dotenv/config";
import express from "express";
import cors from "cors";
import { handleDemo } from "./routes/demo";
import {
  getAdminData,
  updateAdminData,
  resetAdminData,
  updateHeroSection,
  updateFeaturedVideos,
  updateBarbers,
} from "./routes/admin";

export function createServer() {
  const app = express();

  // Middleware
  app.use(cors());
  app.use(express.json());
  app.use(express.urlencoded({ extended: true }));

  // Example API routes
  app.get("/api/ping", (_req, res) => {
    const ping = process.env.PING_MESSAGE ?? "ping";
    res.json({ message: ping });
  });

  app.get("/api/demo", handleDemo);

  // Admin API routes
  app.get("/api/admin", getAdminData);
  app.put("/api/admin", updateAdminData);
  app.post("/api/admin/reset", resetAdminData);
  app.put("/api/admin/hero", updateHeroSection);
  app.put("/api/admin/videos", updateFeaturedVideos);
  app.put("/api/admin/barbers", updateBarbers);

  return app;
}
