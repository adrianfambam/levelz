import { RequestHandler } from "express";
import { AdminData, DEFAULT_ADMIN_DATA } from "../../shared/admin";
import fs from "fs/promises";
import path from "path";

const ADMIN_DATA_FILE = path.join(process.cwd(), "admin-data.json");

// Helper function to read admin data from file
const readAdminData = async (): Promise<AdminData> => {
  try {
    const data = await fs.readFile(ADMIN_DATA_FILE, "utf-8");
    return JSON.parse(data) as AdminData;
  } catch (error) {
    // If file doesn't exist or is invalid, return default data
    console.log("Admin data file not found, using defaults");
    return DEFAULT_ADMIN_DATA;
  }
};

// Helper function to write admin data to file
const writeAdminData = async (data: AdminData): Promise<void> => {
  try {
    await fs.writeFile(ADMIN_DATA_FILE, JSON.stringify(data, null, 2));
  } catch (error) {
    console.error("Error writing admin data:", error);
    throw new Error("Failed to save admin data");
  }
};

// GET /api/admin - Retrieve all admin data
export const getAdminData: RequestHandler = async (req, res) => {
  try {
    const data = await readAdminData();
    res.json(data);
  } catch (error) {
    console.error("Error getting admin data:", error);
    res.status(500).json({ error: "Failed to retrieve admin data" });
  }
};

// PUT /api/admin - Update all admin data
export const updateAdminData: RequestHandler = async (req, res) => {
  try {
    const newData = req.body as AdminData;

    // Basic validation
    if (!newData.heroSection || !newData.featuredVideos || !newData.barbers) {
      return res.status(400).json({ error: "Invalid admin data structure" });
    }

    // Validate featured videos array length
    if (newData.featuredVideos.length !== 6) {
      return res
        .status(400)
        .json({ error: "Featured videos must contain exactly 6 videos" });
    }

    // Validate barbers array length
    if (newData.barbers.length !== 10) {
      return res
        .status(400)
        .json({ error: "Barbers must contain exactly 10 barbers" });
    }

    await writeAdminData(newData);
    res.json({ success: true, message: "Admin data updated successfully" });
  } catch (error) {
    console.error("Error updating admin data:", error);
    res.status(500).json({ error: "Failed to update admin data" });
  }
};

// POST /api/admin/reset - Reset to default data
export const resetAdminData: RequestHandler = async (req, res) => {
  try {
    await writeAdminData(DEFAULT_ADMIN_DATA);
    res.json({ success: true, message: "Admin data reset to defaults" });
  } catch (error) {
    console.error("Error resetting admin data:", error);
    res.status(500).json({ error: "Failed to reset admin data" });
  }
};

// PUT /api/admin/hero - Update hero section only
export const updateHeroSection: RequestHandler = async (req, res) => {
  try {
    const heroData = req.body;
    const currentData = await readAdminData();

    currentData.heroSection = {
      backgroundVideo:
        heroData.backgroundVideo || currentData.heroSection.backgroundVideo,
      featuredVideo:
        heroData.featuredVideo || currentData.heroSection.featuredVideo,
    };

    await writeAdminData(currentData);
    res.json({ success: true, message: "Hero section updated successfully" });
  } catch (error) {
    console.error("Error updating hero section:", error);
    res.status(500).json({ error: "Failed to update hero section" });
  }
};

// PUT /api/admin/videos - Update featured videos only
export const updateFeaturedVideos: RequestHandler = async (req, res) => {
  try {
    const videosData = req.body;
    const currentData = await readAdminData();

    if (!Array.isArray(videosData) || videosData.length !== 6) {
      return res
        .status(400)
        .json({
          error: "Featured videos must be an array of exactly 6 videos",
        });
    }

    currentData.featuredVideos = videosData;
    await writeAdminData(currentData);
    res.json({
      success: true,
      message: "Featured videos updated successfully",
    });
  } catch (error) {
    console.error("Error updating featured videos:", error);
    res.status(500).json({ error: "Failed to update featured videos" });
  }
};

// PUT /api/admin/barbers - Update barbers only
export const updateBarbers: RequestHandler = async (req, res) => {
  try {
    const barbersData = req.body;
    const currentData = await readAdminData();

    if (!Array.isArray(barbersData) || barbersData.length !== 10) {
      return res
        .status(400)
        .json({ error: "Barbers must be an array of exactly 10 barbers" });
    }

    currentData.barbers = barbersData;
    await writeAdminData(currentData);
    res.json({ success: true, message: "Barbers updated successfully" });
  } catch (error) {
    console.error("Error updating barbers:", error);
    res.status(500).json({ error: "Failed to update barbers" });
  }
};
