# Choose Your Barber Section - Complete Code Documentation

## Overview
This is the complete React component code for the "Choose Your Barber" section of your barbershop website. It displays a grid of 10 professional barbers with their photos, names, and booking buttons.

---

## Main Component Code

**File: `client/components/ChooseBarberSection.tsx`**

```tsx
import { Button } from "@/components/ui/button";
import { useState, useEffect } from "react";
import { AdminData, DEFAULT_ADMIN_DATA } from "@shared/admin";

export function ChooseBarberSection() {
  const [adminData, setAdminData] = useState<AdminData>(DEFAULT_ADMIN_DATA);

  useEffect(() => {
    // Load admin data from API
    const loadAdminData = async () => {
      try {
        const response = await fetch("/api/admin");
        if (response.ok) {
          const contentType = response.headers.get("content-type");
          if (contentType && contentType.includes("application/json")) {
            const data = await response.json();
            setAdminData(data);
          } else {
            console.warn("API returned non-JSON response, using defaults");
          }
        } else {
          console.warn(`API returned ${response.status}, using defaults`);
        }
      } catch (error) {
        console.error("Error loading admin data:", error);
        // Use default data if API fails
      }
    };

    loadAdminData();
  }, []);

  const handleBookNow = (barberId: number, barberName: string) => {
    // This could navigate to a booking page or open a modal
    console.log(`Booking with ${barberName} (ID: ${barberId})`);
  };

  return (
    <section
      id="choose-barber"
      className="py-16 px-4"
      style={{
        background: `
          radial-gradient(ellipse at 20% 50%, rgba(30, 30, 30, 0.4) 0%, transparent 60%),
          radial-gradient(ellipse at 80% 20%, rgba(20, 20, 20, 0.3) 0%, transparent 60%),
          radial-gradient(ellipse at 40% 80%, rgba(0, 0, 0, 0.5) 0%, transparent 50%),
          linear-gradient(135deg, #000000 0%, #1a1a1a 25%, #2a2a2a 50%, #1a1a1a 75%, #000000 100%)
        `,
        backgroundSize: "100% 100%, 200% 200%, 150% 150%, 100% 100%",
      }}
    >
      <div className="max-w-7xl mx-auto">
        {/* Title */}
        <div className="text-center mb-16">
          <h2
            className="text-6xl md:text-7xl font-bold text-white mb-4 drop-shadow-2xl"
            style={{ fontFamily: "Milker, sans-serif" }}
          >
            Choose Your Barber
          </h2>
          <p className="text-xl text-gray-200 max-w-2xl mx-auto">
            Select from our team of expert barbers, each with their own unique
            style and specialty
          </p>
        </div>

        {/* Barber Grid - 2 rows of 5 */}
        <div className="grid grid-cols-2 md:grid-cols-5 gap-8 max-w-6xl mx-auto">
          {adminData.barbers.map((barber) => (
            <div
              key={barber.id}
              className="bg-white/10 backdrop-blur-sm rounded-lg p-6 shadow-2xl hover:shadow-3xl transition-all duration-300 hover:scale-105 border border-white/20"
            >
              {/* Barber Photo */}
              <div className="aspect-square mb-4 overflow-hidden rounded-lg">
                <img
                  src={barber.image}
                  alt={`${barber.name} - Professional Barber`}
                  className="w-full h-full object-cover transition-transform duration-300 hover:scale-110"
                  onError={(e) => {
                    // Fallback to a generic avatar if image fails to load
                    const target = e.target as HTMLImageElement;
                    target.src =
                      "https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg?auto=compress&cs=tinysrgb&w=400";
                  }}
                />
              </div>

              {/* Barber Info */}
              <div className="text-center mb-4">
                <h3
                  className="text-lg font-semibold text-white mb-1"
                  style={{ fontFamily: "Milker, sans-serif" }}
                >
                  {barber.name}
                </h3>
                <p className="text-sm text-gray-300">PRO BARBER</p>
              </div>

              {/* Book Now Button */}
              <Button
                onClick={() => handleBookNow(barber.id, barber.name)}
                className="w-full bg-white text-black hover:bg-gray-200 font-semibold py-2 px-4 rounded-lg transition-colors duration-300"
                style={{ fontFamily: "Milker, sans-serif" }}
              >
                Book Now
              </Button>
            </div>
          ))}
        </div>

        {/* Additional Info */}
        <div className="text-center mt-16">
          <p className="text-gray-300 max-w-3xl mx-auto">
            All our barbers are professionally trained and certified. Each
            booking includes a consultation to ensure you get the perfect cut
            that matches your style and preferences.
          </p>
        </div>
      </div>
    </section>
  );
}
```

---

## Key Features

### 🎨 **Visual Design**
- **Black marble gradient background** for dramatic effect
- **Glass morphism cards** with backdrop blur and transparency
- **Hover animations** with scale and shadow effects
- **Responsive grid layout** (2 columns on mobile, 5 on desktop)

### 👥 **Barber Management**
- **Dynamic data loading** from admin API
- **10 barber profiles** with photos, names, and specialties
- **Image fallback** if photos fail to load
- **Admin panel integration** for easy updates

### 🔧 **Technical Features**
- **React functional component** with hooks
- **TypeScript** for type safety
- **TailwindCSS** for styling
- **Responsive design** for all devices
- **Error handling** for API failures

### ⚡ **Interactive Elements**
- **Book Now buttons** for each barber
- **Smooth hover effects** on cards and images
- **Scroll-to-section** functionality from navigation
- **Console logging** for booking actions (ready for backend integration)

---

## Dependencies

The component requires these imports:
- `Button` from your UI component library
- `useState` and `useEffect` React hooks
- `AdminData` and `DEFAULT_ADMIN_DATA` from shared admin types

---

## Current Barber Data

The section currently displays:
1. **KEVIN MANNY**
2. **YOUSIF ABBODI** 
3. **Alex Thompson**
4. **GORIAL**
5. **Sam Carter**
6. **Michael Davis**
7. **Chris Wilson**
8. **Tony Garcia**
9. **Ryan Lee**
10. **Josh Brown**

All barbers show "PRO BARBER" as their specialty subtitle.

---

## Admin Panel Integration

This component is fully integrated with your admin panel at `/admin` where you can:
- Update all 10 barber photos
- Change barber names
- Modify specialties
- All changes save automatically and appear on the live site

---

## How to Use

This component is already integrated into your main landing page. Users can:
1. Scroll down to see the "Choose Your Barber" section
2. Click "BOOK NOW" in the navigation to scroll directly to this section
3. Browse all 10 barber profiles
4. Click individual "Book Now" buttons (currently logs to console, ready for booking system integration)

---

*This code provides a complete, professional barber selection interface that's both visually stunning and functionally robust.*
