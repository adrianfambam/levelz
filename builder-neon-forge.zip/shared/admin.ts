export interface AdminData {
  heroSection: {
    backgroundVideo: string;
    featuredVideo: string;
  };
  featuredVideos: Array<{
    id: string;
    title: string;
    vimeoUrl: string;
  }>;
  barbers: Array<{
    id: number;
    name: string;
    image: string;
    specialty: string;
  }>;
}

export const DEFAULT_ADMIN_DATA: AdminData = {
  heroSection: {
    backgroundVideo: "https://player.vimeo.com/video/1112614378",
    featuredVideo: "https://player.vimeo.com/video/1112615936",
  },
  featuredVideos: [
    {
      id: "video1",
      title: "Featured Video 1",
      vimeoUrl: "https://player.vimeo.com/video/1112616734",
    },
    {
      id: "video2",
      title: "Featured Video 2",
      vimeoUrl: "https://player.vimeo.com/video/1112616764",
    },
    {
      id: "video3",
      title: "Featured Video 3",
      vimeoUrl: "https://player.vimeo.com/video/1112616757",
    },
    {
      id: "video4",
      title: "Featured Video 4",
      vimeoUrl: "https://player.vimeo.com/video/1112616771",
    },
    {
      id: "video5",
      title: "Featured Video 5",
      vimeoUrl: "https://player.vimeo.com/video/1112617442",
    },
    {
      id: "video6",
      title: "Featured Video 6",
      vimeoUrl: "https://player.vimeo.com/video/1112617448",
    },
  ],
  barbers: [
    {
      id: 1,
      name: "KEVIN MANNY",
      image:
        "https://cdn.builder.io/api/v1/image/assets%2Fcd94b92507a346519724ff25cf7be75c%2F11e50100e0fa4f459b51cbab1a82ad45?format=webp&width=800",
      specialty: "Classic Cuts",
    },
    {
      id: 2,
      name: "YOUSIF ABBODI",
      image:
        "https://cdn.builder.io/api/v1/image/assets%2Fcd94b92507a346519724ff25cf7be75c%2F08d8f16f811d456bbf7f7e73fc5ec131?format=webp&width=800",
      specialty: "Modern Styles",
    },
    {
      id: 3,
      name: "Alex Thompson",
      image:
        "https://cdn.builder.io/api/v1/image/assets%2Fcd94b92507a346519724ff25cf7be75c%2F46a34a03e3804dcd83db48d934c9e57b?format=webp&width=800",
      specialty: "Beard Specialist",
    },
    {
      id: 4,
      name: "GORIAL",
      image:
        "https://cdn.builder.io/api/v1/image/assets%2Fcd94b92507a346519724ff25cf7be75c%2Ff39f585aa08e41d198a14c064181ac8b?format=webp&width=800",
      specialty: "Precision Cuts",
    },
    {
      id: 5,
      name: "Sam Carter",
      image:
        "https://cdn.builder.io/api/v1/image/assets%2Fcd94b92507a346519724ff25cf7be75c%2Fff90aacfec034187a270ef7a727f23ce?format=webp&width=800",
      specialty: "Trendy Styles",
    },
    {
      id: 6,
      name: "Michael Davis",
      image:
        "https://cdn.builder.io/api/v1/image/assets%2Fcd94b92507a346519724ff25cf7be75c%2F572f923551bd4cf5a25d5d117f8c0582?format=webp&width=800",
      specialty: "Fades & Tapers",
    },
    {
      id: 7,
      name: "Chris Wilson",
      image:
        "https://cdn.builder.io/api/v1/image/assets%2Fcd94b92507a346519724ff25cf7be75c%2Faa4610318f96490996e50c10c153b6b3?format=webp&width=800",
      specialty: "Classic Gentleman",
    },
    {
      id: 8,
      name: "Tony Garcia",
      image:
        "https://cdn.builder.io/api/v1/image/assets%2Fcd94b92507a346519724ff25cf7be75c%2Fdbba0317f34645958eb8f5c75ec8e161?format=webp&width=800",
      specialty: "Creative Cuts",
    },
    {
      id: 9,
      name: "Ryan Lee",
      image:
        "https://cdn.builder.io/api/v1/image/assets%2Fcd94b92507a346519724ff25cf7be75c%2F3712958c0b2d435780ccd707e2a7dec3?format=webp&width=800",
      specialty: "Hair & Beard",
    },
    {
      id: 10,
      name: "Josh Brown",
      image:
        "https://cdn.builder.io/api/v1/image/assets%2Fcd94b92507a346519724ff25cf7be75c%2F70d2ee8e66b6422587f3a115c69e78b8?format=webp&width=800",
      specialty: "Traditional Cuts",
    },
  ],
};

// Client-side storage utilities
export const adminStorage = {
  get(): AdminData {
    if (typeof window === "undefined") return DEFAULT_ADMIN_DATA;

    try {
      const stored = localStorage.getItem("admin-data");
      if (stored) {
        return JSON.parse(stored);
      }
    } catch (error) {
      console.error("Error reading admin data:", error);
    }

    return DEFAULT_ADMIN_DATA;
  },

  set(data: AdminData): void {
    if (typeof window === "undefined") return;

    try {
      localStorage.setItem("admin-data", JSON.stringify(data));
    } catch (error) {
      console.error("Error saving admin data:", error);
    }
  },

  reset(): void {
    if (typeof window === "undefined") return;

    try {
      localStorage.removeItem("admin-data");
    } catch (error) {
      console.error("Error resetting admin data:", error);
    }
  },
};

// Hook for React components (to be imported separately in client-side code)
// This is kept as a comment since React hooks should only be used on client-side
