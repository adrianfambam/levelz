import { Header } from "@/components/Header";
import { HeroSection } from "@/components/HeroSection";
import { PromoSection } from "@/components/PromoSection";
import { VideoCarousel } from "@/components/VideoCarousel";
import { ChooseBarberSection } from "@/components/ChooseBarberSection";
import { useState, useEffect } from "react";
import { AdminData, DEFAULT_ADMIN_DATA } from "@shared/admin";

export default function Index() {
  const [adminData, setAdminData] = useState<AdminData>(DEFAULT_ADMIN_DATA);

  useEffect(() => {
    // Load admin data from API
    const loadAdminData = async () => {
      try {
        const response = await fetch("/api/admin");
        if (response.ok) {
          const contentType = response.headers.get("content-type");
          if (contentType && contentType.includes("application/json")) {
            const data = await response.json();
            setAdminData(data);
          } else {
            console.warn("API returned non-JSON response, using defaults");
          }
        } else {
          console.warn(`API returned ${response.status}, using defaults`);
        }
      } catch (error) {
        console.error("Error loading admin data:", error);
        // Use default data if API fails
      }
    };

    loadAdminData();
  }, []);

  return (
    <div className="min-h-screen bg-gray-900">
      <Header />
      <HeroSection />
      <VideoCarousel
        videos={adminData.featuredVideos}
        heading="Featured Videos"
        description="Watch our latest video content and highlights"
        autoplay={8000}
        showArrows={true}
      />
      <ChooseBarberSection />
      <PromoSection />
    </div>
  );
}
