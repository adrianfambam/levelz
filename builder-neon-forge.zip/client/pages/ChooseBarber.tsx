import { Header } from "@/components/Header";
import { Button } from "@/components/ui/button";

interface Barber {
  id: number;
  name: string;
  image: string;
  specialty?: string;
}

const barbers: Barber[] = [
  {
    id: 1,
    name: "Marcus Johnson",
    image: "https://images.pexels.com/photos/5234227/pexels-photo-5234227.jpeg?auto=compress&cs=tinysrgb&w=400",
    specialty: "Classic Cuts"
  },
  {
    id: 2,
    name: "Diego Rodriguez",
    image: "https://images.pexels.com/photos/2076930/pexels-photo-2076930.jpeg?auto=compress&cs=tinysrgb&w=400",
    specialty: "Modern Styles"
  },
  {
    id: 3,
    name: "Alex Thompson",
    image: "https://images.pexels.com/photos/3998427/pexels-photo-3998427.jpeg?auto=compress&cs=tinysrgb&w=400",
    specialty: "Beard Specialist"
  },
  {
    id: 4,
    name: "Jordan Mitchell",
    image: "https://images.pexels.com/photos/3998429/pexels-photo-3998429.jpeg?auto=compress&cs=tinysrgb&w=400",
    specialty: "Precision Cuts"
  },
  {
    id: 5,
    name: "Sam Carter",
    image: "https://images.pexels.com/photos/7956486/pexels-photo-7956486.jpeg?auto=compress&cs=tinysrgb&w=400",
    specialty: "Trendy Styles"
  },
  {
    id: 6,
    name: "Michael Davis",
    image: "https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg?auto=compress&cs=tinysrgb&w=400",
    specialty: "Fades & Tapers"
  },
  {
    id: 7,
    name: "Chris Wilson",
    image: "https://images.pexels.com/photos/2379004/pexels-photo-2379004.jpeg?auto=compress&cs=tinysrgb&w=400",
    specialty: "Classic Gentleman"
  },
  {
    id: 8,
    name: "Tony Garcia",
    image: "https://images.pexels.com/photos/1222271/pexels-photo-1222271.jpeg?auto=compress&cs=tinysrgb&w=400",
    specialty: "Creative Cuts"
  },
  {
    id: 9,
    name: "Ryan Lee",
    image: "https://images.pexels.com/photos/1043471/pexels-photo-1043471.jpeg?auto=compress&cs=tinysrgb&w=400",
    specialty: "Hair & Beard"
  },
  {
    id: 10,
    name: "Josh Brown",
    image: "https://images.pexels.com/photos/1848565/pexels-photo-1848565.jpeg?auto=compress&cs=tinysrgb&w=400",
    specialty: "Traditional Cuts"
  }
];

export default function ChooseBarber() {
  const handleBookNow = (barberId: number, barberName: string) => {
    // This could navigate to a booking page or open a modal
    console.log(`Booking with ${barberName} (ID: ${barberId})`);
  };

  return (
    <div className="min-h-screen">
      <Header />
      
      {/* Black and white marble gradient background */}
      <div 
        className="min-h-screen py-16 px-4"
        style={{
          background: `
            radial-gradient(ellipse at 20% 50%, rgba(120, 119, 198, 0.3) 0%, transparent 50%),
            radial-gradient(ellipse at 80% 20%, rgba(255, 255, 255, 0.15) 0%, transparent 50%),
            radial-gradient(ellipse at 40% 80%, rgba(0, 0, 0, 0.1) 0%, transparent 50%),
            linear-gradient(135deg, #000000 0%, #434343 25%, #ffffff 50%, #434343 75%, #000000 100%)
          `,
          backgroundSize: '100% 100%, 200% 200%, 150% 150%, 100% 100%'
        }}
      >
        <div className="max-w-7xl mx-auto">
          {/* Title */}
          <div className="text-center mb-16">
            <h1 
              className="text-6xl md:text-7xl font-bold text-white mb-4 drop-shadow-2xl"
              style={{ fontFamily: 'Milker, sans-serif' }}
            >
              Choose Your Barber
            </h1>
            <p className="text-xl text-gray-200 max-w-2xl mx-auto">
              Select from our team of expert barbers, each with their own unique style and specialty
            </p>
          </div>

          {/* Barber Grid - 2 rows of 5 */}
          <div className="grid grid-cols-2 md:grid-cols-5 gap-8 max-w-6xl mx-auto">
            {barbers.map((barber) => (
              <div 
                key={barber.id}
                className="bg-white/10 backdrop-blur-sm rounded-lg p-6 shadow-2xl hover:shadow-3xl transition-all duration-300 hover:scale-105 border border-white/20"
              >
                {/* Barber Photo */}
                <div className="aspect-square mb-4 overflow-hidden rounded-lg">
                  <img
                    src={barber.image}
                    alt={`${barber.name} - Professional Barber`}
                    className="w-full h-full object-cover transition-transform duration-300 hover:scale-110"
                    onError={(e) => {
                      // Fallback to a generic avatar if image fails to load
                      const target = e.target as HTMLImageElement;
                      target.src = "https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg?auto=compress&cs=tinysrgb&w=400";
                    }}
                  />
                </div>

                {/* Barber Info */}
                <div className="text-center mb-4">
                  <h3 className="text-lg font-semibold text-white mb-1" style={{ fontFamily: 'Milker, sans-serif' }}>
                    {barber.name}
                  </h3>
                  {barber.specialty && (
                    <p className="text-sm text-gray-300">
                      {barber.specialty}
                    </p>
                  )}
                </div>

                {/* Book Now Button */}
                <Button
                  onClick={() => handleBookNow(barber.id, barber.name)}
                  className="w-full bg-white text-black hover:bg-gray-200 font-semibold py-2 px-4 rounded-lg transition-colors duration-300"
                  style={{ fontFamily: 'Milker, sans-serif' }}
                >
                  Book Now
                </Button>
              </div>
            ))}
          </div>

          {/* Additional Info */}
          <div className="text-center mt-16">
            <p className="text-gray-300 max-w-3xl mx-auto">
              All our barbers are professionally trained and certified. Each booking includes a consultation 
              to ensure you get the perfect cut that matches your style and preferences.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
