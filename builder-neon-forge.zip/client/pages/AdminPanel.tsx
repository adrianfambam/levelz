import { useState, useEffect } from "react";
import { Header } from "@/components/Header";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";
import { AdminData, DEFAULT_ADMIN_DATA } from "@shared/admin";

const ADMIN_PASSWORD = "admin123"; // Simple password for demo

export default function AdminPanel() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [password, setPassword] = useState("");
  const [adminData, setAdminData] = useState<AdminData>(DEFAULT_ADMIN_DATA);
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const { toast } = useToast();

  // Load admin data when authenticated
  useEffect(() => {
    if (isAuthenticated) {
      loadAdminData();
    }
  }, [isAuthenticated]);

  const handleLogin = () => {
    if (password === ADMIN_PASSWORD) {
      setIsAuthenticated(true);
      toast({
        title: "Success",
        description: "Welcome to the admin panel!",
      });
    } else {
      toast({
        title: "Error",
        description: "Invalid password",
        variant: "destructive",
      });
    }
  };

  const loadAdminData = async () => {
    setLoading(true);
    try {
      const response = await fetch("/api/admin");
      if (response.ok) {
        const contentType = response.headers.get("content-type");
        if (contentType && contentType.includes("application/json")) {
          const data = await response.json();
          setAdminData(data);
        } else {
          throw new Error("API returned non-JSON response");
        }
      } else {
        throw new Error(`API returned ${response.status}`);
      }
    } catch (error) {
      console.error("Error loading admin data:", error);
      toast({
        title: "Error",
        description: `Failed to load admin data: ${error instanceof Error ? error.message : "Unknown error"}`,
        variant: "destructive",
      });
      // Use default data as fallback
      setAdminData(DEFAULT_ADMIN_DATA);
    } finally {
      setLoading(false);
    }
  };

  const saveAdminData = async () => {
    setSaving(true);
    try {
      const response = await fetch("/api/admin", {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(adminData),
      });

      if (response.ok) {
        toast({
          title: "Success",
          description: "Admin data saved successfully!",
        });
      } else {
        throw new Error("Failed to save admin data");
      }
    } catch (error) {
      console.error("Error saving admin data:", error);
      toast({
        title: "Error",
        description: "Failed to save admin data",
        variant: "destructive",
      });
    } finally {
      setSaving(false);
    }
  };

  const resetToDefaults = async () => {
    if (
      confirm(
        "Are you sure you want to reset all data to defaults? This cannot be undone.",
      )
    ) {
      setSaving(true);
      try {
        const response = await fetch("/api/admin/reset", {
          method: "POST",
        });

        if (response.ok) {
          setAdminData(DEFAULT_ADMIN_DATA);
          toast({
            title: "Success",
            description: "Admin data reset to defaults!",
          });
        } else {
          throw new Error("Failed to reset admin data");
        }
      } catch (error) {
        console.error("Error resetting admin data:", error);
        toast({
          title: "Error",
          description: "Failed to reset admin data",
          variant: "destructive",
        });
      } finally {
        setSaving(false);
      }
    }
  };

  const updateHeroSection = (
    field: "backgroundVideo" | "featuredVideo",
    value: string,
  ) => {
    setAdminData((prev) => ({
      ...prev,
      heroSection: {
        ...prev.heroSection,
        [field]: value,
      },
    }));
  };

  const updateFeaturedVideo = (
    index: number,
    field: "title" | "vimeoUrl",
    value: string,
  ) => {
    setAdminData((prev) => ({
      ...prev,
      featuredVideos: prev.featuredVideos.map((video, i) =>
        i === index ? { ...video, [field]: value } : video,
      ),
    }));
  };

  const updateBarber = (
    index: number,
    field: "name" | "image" | "specialty",
    value: string,
  ) => {
    setAdminData((prev) => ({
      ...prev,
      barbers: prev.barbers.map((barber, i) =>
        i === index ? { ...barber, [field]: value } : barber,
      ),
    }));
  };

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-gray-900">
        <Header />
        <div className="flex items-center justify-center min-h-[600px]">
          <Card className="w-full max-w-md">
            <CardHeader>
              <CardTitle>Admin Panel Access</CardTitle>
              <CardDescription>
                Enter the admin password to access the control panel
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="password">Password</Label>
                <Input
                  id="password"
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  onKeyDown={(e) => e.key === "Enter" && handleLogin()}
                  placeholder="Enter admin password"
                />
              </div>
              <Button onClick={handleLogin} className="w-full">
                Login
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-900">
        <Header />
        <div className="flex items-center justify-center min-h-[600px]">
          <div className="text-white text-xl">Loading admin data...</div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-900">
      <Header />

      <div className="container mx-auto py-8 px-4">
        <div className="flex justify-between items-center mb-8">
          <div>
            <h1
              className="text-3xl font-bold text-white mb-2"
              style={{ fontFamily: "Milker, sans-serif" }}
            >
              Admin Panel
            </h1>
            <p className="text-gray-300">Manage your website content</p>
          </div>
          <div className="space-x-4">
            <Button
              onClick={resetToDefaults}
              variant="outline"
              disabled={saving}
              className="bg-red-600 text-white hover:bg-red-700"
            >
              Reset to Defaults
            </Button>
            <Button
              onClick={saveAdminData}
              disabled={saving}
              className="bg-green-600 text-white hover:bg-green-700"
            >
              {saving ? "Saving..." : "Save All Changes"}
            </Button>
          </div>
        </div>

        <Tabs defaultValue="hero" className="space-y-6">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="hero">Hero Section</TabsTrigger>
            <TabsTrigger value="videos">Featured Videos</TabsTrigger>
            <TabsTrigger value="barbers">Barbers</TabsTrigger>
          </TabsList>

          <TabsContent value="hero" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Hero Section Videos</CardTitle>
                <CardDescription>
                  Edit the background video and featured video on the landing
                  page
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-2">
                  <Label htmlFor="backgroundVideo">Background Video URL</Label>
                  <Input
                    id="backgroundVideo"
                    value={adminData.heroSection.backgroundVideo}
                    onChange={(e) =>
                      updateHeroSection("backgroundVideo", e.target.value)
                    }
                    placeholder="https://player.vimeo.com/video/..."
                  />
                  <p className="text-sm text-gray-500">
                    Vimeo player URL for the background video
                  </p>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="featuredVideo">Featured Video URL</Label>
                  <Input
                    id="featuredVideo"
                    value={adminData.heroSection.featuredVideo}
                    onChange={(e) =>
                      updateHeroSection("featuredVideo", e.target.value)
                    }
                    placeholder="https://player.vimeo.com/video/..."
                  />
                  <p className="text-sm text-gray-500">
                    Vimeo player URL for the featured video on the right side
                  </p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="videos" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Featured Videos Carousel</CardTitle>
                <CardDescription>
                  Edit the 6 videos displayed in the carousel section
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                {adminData.featuredVideos.map((video, index) => (
                  <div
                    key={video.id}
                    className="border rounded-lg p-4 space-y-4"
                  >
                    <h4 className="font-semibold text-lg">Video {index + 1}</h4>

                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor={`video-title-${index}`}>Title</Label>
                        <Input
                          id={`video-title-${index}`}
                          value={video.title}
                          onChange={(e) =>
                            updateFeaturedVideo(index, "title", e.target.value)
                          }
                          placeholder="Video title"
                        />
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor={`video-url-${index}`}>Vimeo URL</Label>
                        <Input
                          id={`video-url-${index}`}
                          value={video.vimeoUrl}
                          onChange={(e) =>
                            updateFeaturedVideo(
                              index,
                              "vimeoUrl",
                              e.target.value,
                            )
                          }
                          placeholder="https://player.vimeo.com/video/..."
                        />
                      </div>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="barbers" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Barber Team</CardTitle>
                <CardDescription>
                  Edit the 10 barber profiles displayed in the Choose Your
                  Barber section
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {adminData.barbers.map((barber, index) => (
                    <div
                      key={barber.id}
                      className="border rounded-lg p-4 space-y-4"
                    >
                      <h4 className="font-semibold text-lg">
                        Barber {index + 1}
                      </h4>

                      <div className="space-y-4">
                        <div className="space-y-2">
                          <Label htmlFor={`barber-name-${index}`}>Name</Label>
                          <Input
                            id={`barber-name-${index}`}
                            value={barber.name}
                            onChange={(e) =>
                              updateBarber(index, "name", e.target.value)
                            }
                            placeholder="Barber name"
                          />
                        </div>

                        <div className="space-y-2">
                          <Label htmlFor={`barber-image-${index}`}>
                            Image URL
                          </Label>
                          <Input
                            id={`barber-image-${index}`}
                            value={barber.image}
                            onChange={(e) =>
                              updateBarber(index, "image", e.target.value)
                            }
                            placeholder="https://..."
                          />
                        </div>

                        <div className="space-y-2">
                          <Label htmlFor={`barber-specialty-${index}`}>
                            Specialty
                          </Label>
                          <Input
                            id={`barber-specialty-${index}`}
                            value={barber.specialty}
                            onChange={(e) =>
                              updateBarber(index, "specialty", e.target.value)
                            }
                            placeholder="Barber specialty"
                          />
                        </div>

                        {barber.image && (
                          <div className="mt-2">
                            <img
                              src={barber.image}
                              alt={barber.name}
                              className="w-20 h-20 rounded object-cover"
                              onError={(e) => {
                                const target = e.target as HTMLImageElement;
                                target.style.display = "none";
                              }}
                            />
                          </div>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
