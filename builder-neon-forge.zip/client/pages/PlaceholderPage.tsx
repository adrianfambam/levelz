import { Header } from "@/components/Header";
import { Button } from "@/components/ui/button";

interface PlaceholderPageProps {
  title: string;
  description: string;
}

export function PlaceholderPage({ title, description }: PlaceholderPageProps) {
  return (
    <div className="min-h-screen bg-gray-900">
      <Header />
      <div className="container mx-auto px-6 py-24 text-center">
        <div className="max-w-2xl mx-auto">
          <h1 className="text-6xl font-black text-white mb-6">{title}</h1>
          <p className="text-xl text-white mb-8">{description}</p>
          <p className="text-white/80 mb-8">
            This page is ready to be customized. Continue prompting to add the specific content you'd like to see here.
          </p>
          <Button
            onClick={() => window.history.back()}
            className="bg-white text-black hover:bg-gray-200 font-bold px-8"
          >
            Go Back
          </Button>
        </div>
      </div>
    </div>
  );
}

export default PlaceholderPage;
