import { Button } from "@/components/ui/button";
import { useState, useEffect, useRef, useCallback } from "react";
import { AdminData, DEFAULT_ADMIN_DATA } from "@shared/admin";
import { VideoBackground } from "./VideoBackground";

export function HeroSection() {
  const [adminData, setAdminData] = useState<AdminData>(DEFAULT_ADMIN_DATA);
  const [videoKey, setVideoKey] = useState(0);
  const [userInteracted, setUserInteracted] = useState(false);
  const [backgroundVideoFailed, setBackgroundVideoFailed] = useState(false);
  const [featuredVideoFailed, setFeaturedVideoFailed] = useState(false);
  const sectionRef = useRef<HTMLElement>(null);
  const restartTimerRef = useRef<NodeJS.Timeout>();
  const visibilityTimerRef = useRef<NodeJS.Timeout>();

  useEffect(() => {
    // Load admin data from API
    const loadAdminData = async () => {
      try {
        const response = await fetch("/api/admin");
        if (response.ok) {
          const contentType = response.headers.get("content-type");
          if (contentType && contentType.includes("application/json")) {
            const data = await response.json();
            setAdminData(data);
          } else {
            console.warn("API returned non-JSON response, using defaults");
          }
        } else {
          console.warn(`API returned ${response.status}, using defaults`);
        }
      } catch (error) {
        console.error("Error loading admin data:", error);
      }
    };

    loadAdminData();
  }, []);

  // Restart videos mechanism
  const restartVideos = useCallback(() => {
    console.log("Restarting videos for better reliability...");
    setVideoKey((prev) => prev + 1);
    setBackgroundVideoFailed(false);
    setFeaturedVideoFailed(false);
  }, []);

  // Periodic restart to prevent video stopping (every 45 seconds)
  useEffect(() => {
    restartTimerRef.current = setInterval(() => {
      if (!backgroundVideoFailed || !featuredVideoFailed) {
        restartVideos();
      }
    }, 45000);

    return () => {
      if (restartTimerRef.current) {
        clearInterval(restartTimerRef.current);
      }
    };
  }, [restartVideos, backgroundVideoFailed, featuredVideoFailed]);

  // Enhanced Intersection Observer for video restart
  useEffect(() => {
    const currentSection = sectionRef.current;
    if (!currentSection) return;

    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            // Clear any existing timer
            if (visibilityTimerRef.current) {
              clearTimeout(visibilityTimerRef.current);
            }

            // Restart videos when section becomes visible
            visibilityTimerRef.current = setTimeout(() => {
              restartVideos();
            }, 1000);
          }
        });
      },
      {
        threshold: [0.1, 0.5, 0.9],
        rootMargin: "100px 0px",
      },
    );

    observer.observe(currentSection);

    return () => {
      observer.disconnect();
      if (visibilityTimerRef.current) {
        clearTimeout(visibilityTimerRef.current);
      }
    };
  }, [restartVideos]);

  // Handle user interaction for autoplay policies
  const handleUserInteraction = useCallback(() => {
    if (!userInteracted) {
      setUserInteracted(true);
      setTimeout(() => {
        restartVideos();
      }, 200);
    }
  }, [userInteracted, restartVideos]);

  // Page visibility change handler
  useEffect(() => {
    const handleVisibilityChange = () => {
      if (!document.hidden && userInteracted) {
        // Page became visible again, restart videos
        setTimeout(() => {
          restartVideos();
        }, 1000);
      }
    };

    document.addEventListener("visibilitychange", handleVisibilityChange);
    return () => {
      document.removeEventListener("visibilitychange", handleVisibilityChange);
    };
  }, [restartVideos, userInteracted]);

  // User interaction listeners
  useEffect(() => {
    const events = ["click", "touchstart", "scroll", "mousemove"];

    const handleInteraction = () => {
      handleUserInteraction();
    };

    events.forEach((event) => {
      document.addEventListener(event, handleInteraction, {
        once: true,
        passive: true,
      });
    });

    return () => {
      events.forEach((event) => {
        document.removeEventListener(event, handleInteraction);
      });
    };
  }, [handleUserInteraction]);

  const handleScrollToBarbers = () => {
    handleUserInteraction();
    const element = document.getElementById("choose-barber");
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
  };

  // Video error handlers
  const handleBackgroundVideoError = useCallback(() => {
    console.warn("Background video failed, will retry...");
    setBackgroundVideoFailed(true);
    // Retry after delay
    setTimeout(() => {
      restartVideos();
    }, 5000);
  }, [restartVideos]);

  const handleFeaturedVideoError = useCallback(() => {
    console.warn("Featured video failed, will retry...");
    setFeaturedVideoFailed(true);
    // Retry after delay
    setTimeout(() => {
      restartVideos();
    }, 3000);
  }, [restartVideos]);

  return (
    <section
      ref={sectionRef}
      className="relative w-full min-h-[600px] flex items-center overflow-hidden"
      onClick={handleUserInteraction}
    >
      {/* Video Background */}
      <div className="absolute inset-0 w-full h-full overflow-hidden">
        {!backgroundVideoFailed ? (
          <VideoBackground
            videoUrl={adminData.heroSection.backgroundVideo}
            className="absolute"
            style={{
              width: "120vw",
              height: "120vh",
              left: "50%",
              top: "50%",
              transform: "translate(-50%, -50%)",
              minWidth: "120vw",
              minHeight: "120vh",
            }}
            isBackground={true}
            onError={handleBackgroundVideoError}
            restartKey={videoKey}
          />
        ) : (
          // Fallback static background
          <div
            className="absolute inset-0 bg-gradient-to-br from-black via-gray-900 to-black"
            style={{
              backgroundImage: `url('https://cdn.builder.io/api/v1/image/assets%2F794e5ede76fc48b1bc276afc947bb10b%2F8236db906f0b4cf4a852fd5b8d793972?format=webp&width=1920')`,
              backgroundSize: "cover",
              backgroundPosition: "center",
              opacity: 0.3,
            }}
          />
        )}

        {/* Dark overlay */}
        <div className="absolute inset-0 bg-black bg-opacity-60"></div>

        {/* Manual controls for debugging */}
        {userInteracted && (
          <div className="absolute top-4 right-4 z-50 flex gap-2">
            <button
              onClick={restartVideos}
              className="bg-black/70 text-white px-3 py-1 rounded text-sm opacity-0 hover:opacity-100 transition-opacity backdrop-blur-sm"
              title="Restart videos if they stop playing"
            >
              🔄 Restart
            </button>
            {(backgroundVideoFailed || featuredVideoFailed) && (
              <div className="bg-red-600/70 text-white px-2 py-1 rounded text-xs backdrop-blur-sm">
                Video fallback active
              </div>
            )}
          </div>
        )}
      </div>

      {/* Content */}
      <div className="relative z-10 w-full px-8">
        <div className="grid grid-cols-2 gap-12 items-center">
          {/* Left Side - Logo */}
          <div className="flex flex-col items-center space-y-8">
            <img
              src="https://cdn.builder.io/api/v1/image/assets%2F794e5ede76fc48b1bc276afc947bb10b%2F8236db906f0b4cf4a852fd5b8d793972?format=webp&width=800"
              alt="Logo"
              className="w-[768px] h-auto drop-shadow-2xl"
              loading="eager"
            />
            <Button
              onClick={handleScrollToBarbers}
              className="bg-white text-black hover:bg-gray-100 font-bold text-lg px-8 py-4 rounded-full transition-all duration-300 hover:scale-105"
            >
              BOOK NOW
            </Button>
          </div>

          {/* Right Side - Featured Video */}
          <div className="flex justify-center">
            <div className="relative">
              {!featuredVideoFailed ? (
                <VideoBackground
                  videoUrl={adminData.heroSection.featuredVideo}
                  className="w-[600px] h-[400px] rounded-lg"
                  style={{
                    filter:
                      "drop-shadow(0 0 30px rgba(255, 255, 255, 0.8)) drop-shadow(0 0 60px rgba(255, 255, 255, 0.6)) drop-shadow(0 0 90px rgba(255, 255, 255, 0.4))",
                    boxShadow:
                      "0 0 40px rgba(255, 255, 255, 0.9), 0 0 80px rgba(255, 255, 255, 0.7), inset 0 0 20px rgba(255, 255, 255, 0.3)",
                  }}
                  onError={handleFeaturedVideoError}
                  restartKey={videoKey}
                />
              ) : (
                // Fallback for featured video
                <div
                  className="w-[600px] h-[400px] rounded-lg bg-gradient-to-br from-gray-800 to-black flex items-center justify-center cursor-pointer"
                  style={{
                    filter:
                      "drop-shadow(0 0 30px rgba(255, 255, 255, 0.8)) drop-shadow(0 0 60px rgba(255, 255, 255, 0.6)) drop-shadow(0 0 90px rgba(255, 255, 255, 0.4))",
                    boxShadow:
                      "0 0 40px rgba(255, 255, 255, 0.9), 0 0 80px rgba(255, 255, 255, 0.7), inset 0 0 20px rgba(255, 255, 255, 0.3)",
                  }}
                  onClick={() => {
                    setFeaturedVideoFailed(false);
                    restartVideos();
                  }}
                >
                  <div className="text-center text-white">
                    <div className="text-6xl mb-4">▶️</div>
                    <div className="text-lg font-semibold">
                      Click to reload video
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
