export function PromoSection() {
  return (
    <section className="bg-black py-12">
      <div className="container mx-auto px-6">
        {/* Empty section with black background */}
      </div>
    </section>
  );
}
