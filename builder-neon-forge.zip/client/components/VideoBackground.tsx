import { useEffect, useRef, useState, useCallback } from "react";

interface VideoBackgroundProps {
  videoUrl: string;
  className?: string;
  style?: React.CSSProperties;
  isBackground?: boolean;
  onError?: () => void;
  restartKey?: number;
}

export function VideoBackground({
  videoUrl,
  className = "",
  style = {},
  isBackground = false,
  onError,
  restartKey = 0,
}: VideoBackgroundProps) {
  const iframeRef = useRef<HTMLIFrameElement>(null);
  const [loadAttempts, setLoadAttempts] = useState(0);
  const [isLoaded, setIsLoaded] = useState(false);
  const maxRetries = 3;

  // Enhanced video URL with comprehensive parameters
  const getOptimizedVideoUrl = useCallback(
    (baseUrl: string) => {
      try {
        const url = new URL(baseUrl);
        const params = new URLSearchParams(url.search);

        // Core autoplay parameters
        params.set("autoplay", "1");
        params.set("loop", "1");
        params.set("muted", "1");

        // Hide Vimeo UI elements
        params.set("byline", "0");
        params.set("title", "0");
        params.set("portrait", "0");
        params.set("controls", "0");

        // Enhanced reliability parameters
        params.set("autopause", "0"); // Prevent auto-pausing
        params.set("quality_selector", "0"); // Hide quality selector
        params.set("pip", "0"); // Disable picture-in-picture
        params.set("keyboard", "0"); // Disable keyboard controls
        params.set("fullscreen", "0"); // Disable fullscreen button

        // Background video specific
        if (isBackground) {
          params.set("background", "1");
          params.set("transparent", "0");
          params.set("dnt", "1"); // Do not track
        }

        // Performance parameters
        params.set("preload", "auto");
        params.set("playsinline", "1");

        // Cache busting and retry mechanism
        params.set("t", `${Date.now()}-${restartKey}-${loadAttempts}`);

        return `${url.origin}${url.pathname}?${params.toString()}`;
      } catch (error) {
        console.error("Error constructing video URL:", error);
        return baseUrl;
      }
    },
    [isBackground, restartKey, loadAttempts],
  );

  // Handle iframe load events
  const handleLoad = useCallback(() => {
    setIsLoaded(true);
    console.log("Video loaded successfully");
  }, []);

  const handleError = useCallback(() => {
    console.warn(
      `Video load failed (attempt ${loadAttempts + 1}/${maxRetries})`,
    );

    if (loadAttempts < maxRetries) {
      // Retry loading with delay
      setTimeout(
        () => {
          setLoadAttempts((prev) => prev + 1);
          setIsLoaded(false);
        },
        2000 * (loadAttempts + 1),
      ); // Exponential backoff
    } else {
      console.error("Video failed to load after maximum retries");
      onError?.();
    }
  }, [loadAttempts, maxRetries, onError]);

  // Reset load attempts when restartKey changes
  useEffect(() => {
    setLoadAttempts(0);
    setIsLoaded(false);
  }, [restartKey]);

  // Preload video for better performance
  useEffect(() => {
    if (iframeRef.current && isLoaded) {
      // Post message to iframe to ensure autoplay
      try {
        const iframe = iframeRef.current;
        const message = {
          method: "play",
        };
        iframe.contentWindow?.postMessage(JSON.stringify(message), "*");
      } catch (error) {
        // Ignore postMessage errors
      }
    }
  }, [isLoaded, restartKey]);

  const optimizedUrl = getOptimizedVideoUrl(videoUrl);

  return (
    <>
      <iframe
        ref={iframeRef}
        src={optimizedUrl}
        className={className}
        style={style}
        frameBorder="0"
        allow="autoplay; fullscreen; accelerometer; gyroscope; picture-in-picture; encrypted-media"
        allowFullScreen
        title={isBackground ? "Background Video" : "Video"}
        onLoad={handleLoad}
        onError={handleError}
        loading="eager"
        sandbox="allow-scripts allow-same-origin allow-presentation"
      />

      {/* Loading indicator for debugging */}
      {!isLoaded && loadAttempts > 0 && (
        <div
          className="absolute inset-0 flex items-center justify-center bg-black/20 text-white text-sm z-10"
          style={style}
        >
          Loading video... (attempt {loadAttempts}/{maxRetries})
        </div>
      )}
    </>
  );
}
