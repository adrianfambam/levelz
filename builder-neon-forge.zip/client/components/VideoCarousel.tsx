import { useEffect, useRef, useState } from 'react';

interface Video {
  id: string;
  title?: string;
  vimeoUrl: string;
}

interface VideoCarouselProps {
  videos: Video[];
  heading?: string;
  description?: string;
  autoplay?: number;
  showArrows?: boolean;
}

export function VideoCarousel({ 
  videos, 
  heading = "Featured Videos", 
  description,
  autoplay = 8000,
  showArrows = true 
}: VideoCarouselProps) {
  const sliderRef = useRef<HTMLDivElement>(null);
  const [flickity, setFlickity] = useState<any>(null);
  const sectionId = useRef(`video-carousel-${Math.random().toString(36).substr(2, 9)}`);

  useEffect(() => {
    // Load Flickity dynamically
    const loadFlickity = async () => {
      if (typeof window !== 'undefined' && !window.Flickity) {
        const script = document.createElement('script');
        script.src = 'https://cdn.shopify.com/s/files/1/0577/7673/4361/files/flickity-2.3.0.pkgd.min.js?v=1671485005';
        script.async = true;
        script.onload = () => initializeCarousel();
        document.head.appendChild(script);
      } else if (window.Flickity) {
        initializeCarousel();
      }
    };

    const initializeCarousel = () => {
      if (sliderRef.current && window.Flickity) {
        const flkty = new window.Flickity(sliderRef.current, {
          cellAlign: 'center',
          autoPlay: autoplay > 0 ? autoplay : false,
          draggable: videos.length > 4 ? '>1' : false,
          contain: false,
          wrapAround: videos.length > 4,
          adaptiveHeight: false,
          watchCSS: false,
          imagesLoaded: true,
          prevNextButtons: false,
          pageDots: false,
          on: {
            staticClick: function(event: any, pointer: any, cellElement: any, cellIndex: number) {
              if (typeof cellIndex === 'number') {
                this.selectCell(cellIndex);
                // All videos continue to autoplay - no need to pause others
              }
            },
            change: function() {
              // All videos continue to autoplay - no need to change autoplay settings
            },
            ready: () => {
              setTimeout(() => {
                sliderRef.current?.classList.add('onhow__stretch-height');
                // Set all videos to autoplay
                const allVideos = sliderRef.current?.querySelectorAll('iframe');
                if (allVideos?.length) {
                  allVideos.forEach((video: HTMLIFrameElement) => {
                    const baseUrl = video.src.split('?')[0];
                    const params = new URLSearchParams(video.src.split('?')[1] || '');
                    params.set('autoplay', '1');
                    video.src = `${baseUrl}?${params.toString()}`;
                  });
                }
              }, 500);
            }
          }
        });
        
        setFlickity(flkty);
      }
    };

    loadFlickity();

    return () => {
      if (flickity) {
        flickity.destroy();
      }
    };
  }, [videos.length, autoplay]);

  const handlePrevious = () => {
    if (flickity) {
      flickity.previous();
    }
  };

  const handleNext = () => {
    if (flickity) {
      flickity.next();
    }
  };

  const handleSoundToggle = (index: number, event: React.MouseEvent) => {
    event.preventDefault();
    event.stopPropagation();

    const button = event.currentTarget as HTMLElement;
    const videos = sliderRef.current?.querySelectorAll('iframe');

    if (videos?.length) {
      const selectedVideo = videos[flickity?.selectedIndex || 0];
      const isOn = button.classList.contains('onhow__sound-button--on');

      // Toggle sound for selected video
      const baseUrl = selectedVideo.src.split('?')[0];
      const params = new URLSearchParams(selectedVideo.src.split('?')[1] || '');

      if (isOn) {
        params.set('muted', '1');
      } else {
        params.set('muted', '0');
      }

      selectedVideo.src = `${baseUrl}?${params.toString()}`;

      // Toggle all sound buttons
      const soundButtons = sliderRef.current?.querySelectorAll('.onhow__sound-button');
      soundButtons?.forEach(btn => btn.classList.toggle('onhow__sound-button--on'));
    }
  };

  return (
    <section 
      id={`DP--${sectionId.current}`} 
      className={`DP--${sectionId.current} onhow__videos-slider onhow__section`}
      style={{
        background: '#000000', // black
        paddingTop: '40px',
        paddingBottom: '40px',
        overflow: 'visible'
      }}
    >
      <style jsx>{`
        .flickity-enabled{position:relative}.flickity-enabled:focus{outline:0;box-shadow: none;}.flickity-viewport{overflow:hidden;position:relative;height:100%}.flickity-slider{position:absolute;width:100%;height:100%}.flickity-enabled.is-draggable{-webkit-tap-highlight-color:transparent;-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none}.flickity-enabled.is-draggable .flickity-viewport{cursor:move;cursor:-webkit-grab;cursor:grab}.flickity-enabled.is-draggable .flickity-viewport.is-pointer-down{cursor:-webkit-grabbing;cursor:grabbing}.flickity-button{position:absolute;background:hsla(0,0%,100%,.75);border:none;color:#333}.flickity-button:hover{background:#fff;cursor:pointer}.flickity-button:focus{outline:0;box-shadow:0 0 0 5px #19f}.flickity-button:active{opacity:.6}.flickity-button:disabled{opacity:.3;cursor:auto;pointer-events:none}.flickity-button-icon{fill:currentColor}.flickity-prev-next-button{top:50%;width:44px;height:44px;border-radius:50%;transform:translateY(-50%)}.flickity-prev-next-button.previous{left:10px}.flickity-prev-next-button.next{right:10px}.flickity-rtl .flickity-prev-next-button.previous{left:auto;right:10px}.flickity-rtl .flickity-prev-next-button.next{right:auto;left:10px}.flickity-prev-next-button .flickity-button-icon{position:absolute;left:20%;top:20%;width:60%;height:60%}.flickity-page-dots{position:absolute;width:100%;bottom:-25px;padding:0;margin:0;list-style:none;text-align:center;line-height:1}.flickity-rtl .flickity-page-dots{direction:rtl}.flickity-page-dots .dot{display:inline-block;width:10px;height:10px;margin:0 8px;background:#333;border-radius:50%;opacity:.25;cursor:pointer}.flickity-page-dots .dot.is-selected{opacity:1}

        #DP--${sectionId.current} .onhow__sizer {
          width: 100%;
        }

        #DP--${sectionId.current} .onhow__section-title {
          text-align: center;
          margin-bottom: ${description ? '20px' : '40px'};
          color: #ffffff;
          font-size: 28px;
          letter-spacing: 0px;
          font-family: 'Milker', sans-serif;
        }

        #DP--${sectionId.current} .onhow__section-description {
          text-align: center;
          margin-bottom: 40px;
          color: #ffffff;
          font-size: 16px;
          line-height: calc(3px + 2.5ex + 3px);
          font-family: 'Milker', sans-serif;
        }

        #DP--${sectionId.current} .onhow__section-description p {
          margin: 0 0 1em 0;
          color: inherit;
          font-size: inherit;
          line-height: inherit;
        }

        #DP--${sectionId.current} .onhow__section-description p:last-child {
          margin-bottom: 0;
        }

        #DP--${sectionId.current} .onhow__flex--main {
          position: relative;
          align-items: center;
        }

        #DP--${sectionId.current} .onhow__videos {
          flex: 1 0 60%;
          overflow: visible;
          padding-bottom: 20px;
        }

        #DP--${sectionId.current} .onhow__video-slider {
          margin: auto;
          overflow: visible !important;
          padding-bottom: 60px; 
        }

        #DP--${sectionId.current} .onhow__videos-wrapper,
        #DP--${sectionId.current} .onhow__videos,
        #DP--${sectionId.current} .onhow__flex--main,
        #DP--${sectionId.current} .onhow__sizer,
        #DP--${sectionId.current} .flickity-slider {
          overflow: visible !important;
        }

        #DP--${sectionId.current} .onhow__item {
          --final-slide-width: min(350px, 90vw);
          --slide-height: calc(var(--final-slide-width) * 1.32);
          --selected-slide-height: calc(var(--final-slide-width) * 1.32);
          height: auto;
          width: var(--final-slide-width);
          margin: 0 5px;
          margin-bottom: 25px;
          display: inline-block;
          overflow: visible;
          transition: all 0.2s ease;
          position: relative;
          z-index: 1;
        }

        #DP--${sectionId.current} .is-selected {
          transform: translateY(-4px);
          z-index: 50;
        }

        #DP--${sectionId.current} .onhow__item > a {
          text-decoration: none;
        }

        #DP--${sectionId.current} .onhow__stretch-height .onhow__item {
          height: 100%;
        }

        #DP--${sectionId.current} .is-selected .onhow__video-wrapper {
          padding-top: 0;
        }

        #DP--${sectionId.current} .onhow__video-inner {
            width: 100%;
        }

        #DP--${sectionId.current} .is-selected .onhow__hosted-video {
          width: 100%;
          min-height: var(--selected-slide-height);
          display: block;
          object-fit: cover;
        }

        #DP--${sectionId.current} .onhow__video {
          height: 100%;
          display: flex;
          text-align: center;
          align-items: flex-start;
          position: relative;
          overflow: visible;
        }

        #DP--${sectionId.current} .onhow__video-wrapper {
          width: 100%;
          padding-top: 0;
          transition: all 0.5s ease;
          position: relative;
          height: var(--slide-height);
        }

        #DP--${sectionId.current} .onhow__hosted-video {
          width: 100%;
          min-height: var(--slide-height);
          display: block;
          object-fit: cover;
          border-radius: 15px;
          transition: all 0.5s ease;
        }

        #DP--${sectionId.current} .onhow__video-content {
          width: 100%;
          margin: 0 auto;
          display: flex;
          flex-direction: column;
          justify-content: flex-end;
          align-items: center;
          border-radius: 15px;
          height: 100%;
          padding: 15px 10px;
          position: absolute;
          bottom: 0;
          left: 0;
          right: 0;
          transition: all 0.2s linear;
          z-index: 2;
          background: linear-gradient(transparent 0%, rgba(0,0,0,0.3) 70%, rgba(0,0,0,0.6) 100%);
        }

        #DP--${sectionId.current} .onhow__absolute-link {
          position: absolute;
          top: 0;
          left: 0;
          right: 0;
          bottom: 0;
          z-index: 1;
        }

        #DP--${sectionId.current} .onhow__item:hover {
          transform: translateY(-2px);
          z-index: 100;
        }

        #DP--${sectionId.current} .onhow__video-content:hover {
          box-shadow: none;
        }

        #DP--${sectionId.current} .onhow__sound-button {
          cursor: pointer;
          background-color: rgba(255, 255, 255, 0.5);
          border-radius: 50%;
          position: absolute;
          bottom: 0;
          right: 0;
          width: 35px;
          height: 35px;
          margin: 10px;
          padding: 5px;
          background-image: url("data:image/svg+xml,%3Csvg width='24' height='24' xmlns='http://www.w3.org/2000/svg' fill-rule='evenodd' clip-rule='evenodd'%3E%3Cpath d='M18 23l-9.305-5.998.835-.651 7.47 4.815v-10.65l1-.781v13.265zm0-15.794l5.384-4.206.616.788-23.384 18.264-.616-.788 5.46-4.264h-2.46v-10h5.691l9.309-6v6.206zm-11.26 8.794l1.26-.984v-7.016h-4v8h2.74zm10.26-8.013v-5.153l-8 5.157v6.244l8-6.248z'/%3E%3C/svg%3E");
          background-size: 65%;
          background-position: center center;
          background-repeat: no-repeat;
        }

        #DP--${sectionId.current} .onhow__sound-button--on {
          background-image: url("data:image/svg+xml,%3Csvg width='24' height='24' xmlns='http://www.w3.org/2000/svg' fill-rule='evenodd' clip-rule='evenodd'%3E%3Cpath d='M15 23l-9.309-6h-5.691v-10h5.691l9.309-6v22zm-9-15.009v8.018l8 5.157v-18.332l-8 5.157zm14.228-4.219c2.327 1.989 3.772 4.942 3.772 8.229 0 3.288-1.445 6.241-3.77 8.229l-.708-.708c2.136-1.791 3.478-4.501 3.478-7.522s-1.342-5.731-3.478-7.522l.706-.706zm-2.929 2.929c1.521 1.257 2.476 3.167 2.476 5.299 0 2.132-.955 4.042-2.476 5.299l-.706-.706c1.331-1.063 2.182-2.729 2.182-4.591 0-1.863-.851-3.529-2.184-4.593l.708-.708zm-12.299 1.299h-4v8h4v-8z'/%3E%3C/svg%3E");
        }

        #DP--${sectionId.current} .onhow__text-area {
          flex: 1;
          text-align: center;
          display: flex;
          flex-direction: column;
          width: 100%;
          align-items: center;
          justify-content: flex-end;
          color: white;
        }

        #DP--${sectionId.current} .onhow__text-area .onhow__text {
          color: white;
        }

        #DP--${sectionId.current} .onhow__text-area .onhow__text p {
          color: white;
          margin: 0 0 8px 0;
          font-weight: 600;
          font-family: 'Milker', sans-serif;
        }

        #DP--${sectionId.current} .onhow__view-product {
          display: inline-block;
          padding: 8px 16px;
          background: #121212;
          color: #ffffff;
          border-radius: 4px;
          margin-top: 5px;
          text-decoration: none;
          font-weight: 600;
          font-size: 14px;
        }

        #DP--${sectionId.current} .onhow__videos-nav {
          width: fit-content;
          margin: 0 auto;
          display: flex;
          gap: 20px;
          margin-top: 20px;
          position: relative;
          z-index: 5;
        }

        #DP--${sectionId.current} .onhow__nav-button {
          cursor: pointer;
          width: 38px;
          height: 38px;
          transform: scale(1.6);
          transition: all 0.3s ease;
        }

        #DP--${sectionId.current} .onhow__videos-wrapper:after {
          content: 'flickity';
          display: none;
        }

        #DP--${sectionId.current} .onhow__videos-wrapper:not(.flickity-enabled) {
          display: flex;
          gap: 10px;
          overflow: visible;
        }

        #DP--${sectionId.current} .onhow__videos-wrapper {
          overflow: visible;
        }

        #DP--${sectionId.current} .flickity-slider {
          top: 0;
        }

        @media (max-width: 768px) {
          #DP--${sectionId.current} {
            padding-top: 20px;
            padding-bottom: 20px;
          }

          #DP--${sectionId.current} .onhow__sizer {
            margin: 0 auto;
          }

          #DP--${sectionId.current} .onhow__video-slider {
            padding-bottom: 45px;
          }

          #DP--${sectionId.current} .onhow__item {
            --final-slide-width: min(280px, 85vw);
            --slide-height: calc(var(--final-slide-width) * 1.2);
            --selected-slide-height: calc(var(--final-slide-width) * 1.2);
            max-height: 50vh;
            margin-bottom: 20px;
          }

          #DP--${sectionId.current} .onhow__hosted-video {
            max-height: 45vh;
            object-fit: cover;
          }

          #DP--${sectionId.current} .onhow__section-title {
            font-size: 24px;
            margin-bottom: ${description ? '10px' : '25px'};
          }

          #DP--${sectionId.current} .onhow__section-description {
            font-size: 14px;
            margin-bottom: 25px;
          }

          #DP--${sectionId.current} .onhow__nav-button {
            transform: scale(1.2);
          }

          #DP--${sectionId.current} .onhow__videos-nav {
            margin-top: 13px;
          }
        }
      `}</style>
      
      <div className="onhow__sizer">
        {heading && (
          <h2 className="onhow__section-title">{heading}</h2>
        )}
        
        {description && (
          <div className="onhow__section-description">
            <p>{description}</p>
          </div>
        )}

        <div className="onhow__flex onhow__flex--main">
          <div className="onhow__videos">
            <div 
              ref={sliderRef}
              id={`slider-${sectionId.current}`} 
              className="onhow__videos-wrapper onhow__video-slider"
            >
              {videos.map((video, index) => (
                <div 
                  key={video.id}
                  className={`onhow__item onhow__video-${index + 1} onhow__block-${video.id}`}
                >
                  <div className="onhow__video">
                    <div className="onhow__video-inner">
                      <div className="onhow__video-wrapper">
                        <iframe
                          className="onhow__hosted-video"
                          width="2000"
                          height="100"
                          src={`${video.vimeoUrl}?autoplay=1&loop=1&byline=0&title=0&muted=1&background=1`}
                          frameBorder="0"
                          allow="autoplay; fullscreen"
                          allowFullScreen
                          loading="lazy"
                        />
                        <div 
                          className="onhow__sound-button"
                          onClick={(e) => handleSoundToggle(index, e)}
                        ></div>
                      </div>
                      {video.title && (
                        <div className="onhow__video-content">
                          <div className="onhow__text-area">
                            <div className="onhow__text">
                              <p>{video.title}</p>
                            </div>
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
            {showArrows && (
              <div className="onhow__videos-nav">
                <div 
                  className="onhow__nav-button onhow__nav-button--prev"
                  onClick={handlePrevious}
                >
                  <svg width="25" height="25" xmlns="http://www.w3.org/2000/svg" fillRule="evenodd" clipRule="evenodd">
                    <path d="M12 0c6.623 0 12 5.377 12 12s-5.377 12-12 12-12-5.377-12-12 5.377-12 12-12zm0 1c6.071 0 11 4.929 11 11s-4.929 11-11 11-11-4.929-11-11 4.929-11 11-11zm3 5.753l-6.44 5.247 6.44 5.263-.678.737-7.322-6 7.335-6 .665.753z" fill="none" stroke="#ffffff"/>
                  </svg>
                </div>
                <div 
                  className="onhow__nav-button onhow__nav-button--next"
                  onClick={handleNext}
                >
                  <svg width="25" height="25" xmlns="http://www.w3.org/2000/svg" fillRule="evenodd" clipRule="evenodd">
                    <path d="M12 0c6.623 0 12 5.377 12 12s-5.377 12-12 12-12-5.377-12-12 5.377-12 12-12zm0 1c6.071 0 11 4.929 11 11s-4.929 11-11 11-11-4.929-11-11 4.929-11 11-11zm-3 5.753l6.44 5.247-6.44 5.263.678.737 7.322-6-7.335-6-.665.753z" fill="none" stroke="#ffffff"/>
                  </svg>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </section>
  );
}

// Declare Flickity on window object for TypeScript
declare global {
  interface Window {
    Flickity: any;
  }
}
