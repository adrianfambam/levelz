import { Link } from "react-router-dom";

export function Header() {
  return (
    <header className="bg-black text-white">
      <div className="grid grid-cols-3 items-center px-6 py-4">
        {/* Logo */}
        <div className="flex items-center">
          <Link to="/" className="flex items-center">
            <img
              src="https://cdn.builder.io/api/v1/image/assets%2F794e5ede76fc48b1bc276afc947bb10b%2Fdad2f71962dc412ba37bc2363a3e2899?format=webp&width=800"
              alt="Zo's Logo"
              className="h-12 w-auto"
            />
          </Link>
        </div>

        {/* Navigation - Centered */}
        <nav className="hidden md:flex items-center justify-center space-x-8" style={{ fontFamily: 'Milker, sans-serif' }}>
          <Link to="/" className="text-white hover:text-gray-300 font-medium">Home</Link>
          <Link to="/about" className="text-white hover:text-gray-300 font-medium">About Us</Link>
          <Link to="/services" className="text-white hover:text-gray-300 font-medium">Services</Link>
          <Link to="/blog" className="text-white hover:text-gray-300 font-medium">Blog</Link>
          <a
            href="#choose-barber"
            className="text-white hover:text-gray-300 font-medium cursor-pointer"
            onClick={(e) => {
              e.preventDefault();
              const element = document.getElementById('choose-barber');
              if (element) {
                element.scrollIntoView({ behavior: 'smooth' });
              }
            }}
          >
            BOOK NOW
          </a>
        </nav>

        {/* Empty right column for balance */}
        <div></div>
      </div>
    </header>
  );
}
