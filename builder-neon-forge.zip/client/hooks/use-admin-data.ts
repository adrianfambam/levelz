import { useState, useEffect } from "react";
import { AdminData, DEFAULT_ADMIN_DATA, adminStorage } from "@shared/admin";

// Hook for React components
export const useAdminData = () => {
  const [data, setData] = useState<AdminData>(DEFAULT_ADMIN_DATA);

  useEffect(() => {
    setData(adminStorage.get());
  }, []);

  const updateData = (newData: AdminData) => {
    setData(newData);
    adminStorage.set(newData);
  };

  return { data, updateData };
};
